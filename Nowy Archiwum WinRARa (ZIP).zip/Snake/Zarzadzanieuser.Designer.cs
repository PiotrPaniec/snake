﻿namespace Snake
{
    partial class Zarzadzanieuser
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rekord = new System.Windows.Forms.Label();
            this.uzytkownik = new System.Windows.Forms.Label();
            this.rekordint = new System.Windows.Forms.Label();
            this.login = new System.Windows.Forms.Label();
            this.oldhaslowpisz = new System.Windows.Forms.TextBox();
            this.podajaktualnehaslo = new System.Windows.Forms.Label();
            this.newhaslowpisz = new System.Windows.Forms.TextBox();
            this.newhaslopowtorz = new System.Windows.Forms.TextBox();
            this.podajnowehaslo = new System.Windows.Forms.Label();
            this.pwotorznowehaslo = new System.Windows.Forms.Label();
            this.newloginwpisz = new System.Windows.Forms.TextBox();
            this.podajnowylogin = new System.Windows.Forms.Label();
            this.wstecz = new System.Windows.Forms.Button();
            this.wprowadz = new System.Windows.Forms.Button();
            this.komunikat = new System.Windows.Forms.Label();
            this.usun = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rekord
            // 
            this.rekord.AutoSize = true;
            this.rekord.Location = new System.Drawing.Point(777, 36);
            this.rekord.Name = "rekord";
            this.rekord.Size = new System.Drawing.Size(53, 17);
            this.rekord.TabIndex = 12;
            this.rekord.Text = "rekord:";
            // 
            // uzytkownik
            // 
            this.uzytkownik.AutoSize = true;
            this.uzytkownik.Location = new System.Drawing.Point(750, 9);
            this.uzytkownik.Name = "uzytkownik";
            this.uzytkownik.Size = new System.Drawing.Size(80, 17);
            this.uzytkownik.TabIndex = 11;
            this.uzytkownik.Text = "użytkownik:";
            // 
            // rekordint
            // 
            this.rekordint.AutoSize = true;
            this.rekordint.Location = new System.Drawing.Point(836, 36);
            this.rekordint.Name = "rekordint";
            this.rekordint.Size = new System.Drawing.Size(46, 17);
            this.rekordint.TabIndex = 10;
            this.rekordint.Text = "label3";
            // 
            // login
            // 
            this.login.AutoSize = true;
            this.login.Location = new System.Drawing.Point(836, 9);
            this.login.Name = "login";
            this.login.Size = new System.Drawing.Size(46, 17);
            this.login.TabIndex = 9;
            this.login.Text = "label2";
            // 
            // oldhaslowpisz
            // 
            this.oldhaslowpisz.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.oldhaslowpisz.Location = new System.Drawing.Point(297, 115);
            this.oldhaslowpisz.Name = "oldhaslowpisz";
            this.oldhaslowpisz.Size = new System.Drawing.Size(444, 30);
            this.oldhaslowpisz.TabIndex = 13;
            // 
            // podajaktualnehaslo
            // 
            this.podajaktualnehaslo.AutoSize = true;
            this.podajaktualnehaslo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.podajaktualnehaslo.Location = new System.Drawing.Point(55, 115);
            this.podajaktualnehaslo.Name = "podajaktualnehaslo";
            this.podajaktualnehaslo.Size = new System.Drawing.Size(198, 25);
            this.podajaktualnehaslo.TabIndex = 14;
            this.podajaktualnehaslo.Text = "Podaj aktualne hasło ";
            // 
            // newhaslowpisz
            // 
            this.newhaslowpisz.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.newhaslowpisz.Location = new System.Drawing.Point(297, 180);
            this.newhaslowpisz.Name = "newhaslowpisz";
            this.newhaslowpisz.Size = new System.Drawing.Size(444, 30);
            this.newhaslowpisz.TabIndex = 15;
            // 
            // newhaslopowtorz
            // 
            this.newhaslopowtorz.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.newhaslopowtorz.Location = new System.Drawing.Point(297, 247);
            this.newhaslopowtorz.Name = "newhaslopowtorz";
            this.newhaslopowtorz.Size = new System.Drawing.Size(444, 30);
            this.newhaslopowtorz.TabIndex = 16;
            // 
            // podajnowehaslo
            // 
            this.podajnowehaslo.AutoSize = true;
            this.podajnowehaslo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.podajnowehaslo.Location = new System.Drawing.Point(55, 183);
            this.podajnowehaslo.Name = "podajnowehaslo";
            this.podajnowehaslo.Size = new System.Drawing.Size(171, 25);
            this.podajnowehaslo.TabIndex = 17;
            this.podajnowehaslo.Text = "Podaj nowe haslo ";
            // 
            // pwotorznowehaslo
            // 
            this.pwotorznowehaslo.AutoSize = true;
            this.pwotorznowehaslo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.pwotorznowehaslo.Location = new System.Drawing.Point(55, 247);
            this.pwotorznowehaslo.Name = "pwotorznowehaslo";
            this.pwotorznowehaslo.Size = new System.Drawing.Size(196, 25);
            this.pwotorznowehaslo.TabIndex = 18;
            this.pwotorznowehaslo.Text = "Powtórz nowe hasło  ";
            // 
            // newloginwpisz
            // 
            this.newloginwpisz.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.newloginwpisz.Location = new System.Drawing.Point(297, 312);
            this.newloginwpisz.Name = "newloginwpisz";
            this.newloginwpisz.Size = new System.Drawing.Size(444, 30);
            this.newloginwpisz.TabIndex = 19;
            // 
            // podajnowylogin
            // 
            this.podajnowylogin.AutoSize = true;
            this.podajnowylogin.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.podajnowylogin.Location = new System.Drawing.Point(55, 312);
            this.podajnowylogin.Name = "podajnowylogin";
            this.podajnowylogin.Size = new System.Drawing.Size(169, 25);
            this.podajnowylogin.TabIndex = 20;
            this.podajnowylogin.Text = "Podaj nowy login  ";
            // 
            // wstecz
            // 
            this.wstecz.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.wstecz.Location = new System.Drawing.Point(60, 15);
            this.wstecz.Name = "wstecz";
            this.wstecz.Size = new System.Drawing.Size(75, 38);
            this.wstecz.TabIndex = 21;
            this.wstecz.Text = "<--";
            this.wstecz.UseVisualStyleBackColor = true;
            this.wstecz.Click += new System.EventHandler(this.wsteczClick);
            // 
            // wprowadz
            // 
            this.wprowadz.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.wprowadz.Location = new System.Drawing.Point(384, 347);
            this.wprowadz.Name = "wprowadz";
            this.wprowadz.Size = new System.Drawing.Size(265, 43);
            this.wprowadz.TabIndex = 22;
            this.wprowadz.Text = "wprowadź zmiany ";
            this.wprowadz.UseVisualStyleBackColor = true;
            this.wprowadz.Click += new System.EventHandler(this.zamiana_userClick);
            // 
            // komunikat
            // 
            this.komunikat.AutoSize = true;
            this.komunikat.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.komunikat.ForeColor = System.Drawing.Color.Red;
            this.komunikat.Location = new System.Drawing.Point(393, 393);
            this.komunikat.Name = "komunikat";
            this.komunikat.Size = new System.Drawing.Size(0, 25);
            this.komunikat.TabIndex = 23;
            // 
            // usun
            // 
            this.usun.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.usun.Location = new System.Drawing.Point(384, 421);
            this.usun.Name = "usun";
            this.usun.Size = new System.Drawing.Size(265, 42);
            this.usun.TabIndex = 24;
            this.usun.Text = "usun konto";
            this.usun.UseVisualStyleBackColor = true;
            this.usun.Click += new System.EventHandler(this.usunClick);
            // 
            // Zarzadzanieuser
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Lime;
            this.ClientSize = new System.Drawing.Size(982, 484);
            this.Controls.Add(this.usun);
            this.Controls.Add(this.komunikat);
            this.Controls.Add(this.wprowadz);
            this.Controls.Add(this.wstecz);
            this.Controls.Add(this.podajnowylogin);
            this.Controls.Add(this.newloginwpisz);
            this.Controls.Add(this.pwotorznowehaslo);
            this.Controls.Add(this.podajnowehaslo);
            this.Controls.Add(this.newhaslopowtorz);
            this.Controls.Add(this.newhaslowpisz);
            this.Controls.Add(this.podajaktualnehaslo);
            this.Controls.Add(this.oldhaslowpisz);
            this.Controls.Add(this.rekord);
            this.Controls.Add(this.uzytkownik);
            this.Controls.Add(this.rekordint);
            this.Controls.Add(this.login);
            this.Name = "Zarzadzanieuser";
            this.Text = "Zarządzanie kontem przez użytkownika";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label rekord;
        private System.Windows.Forms.Label uzytkownik;
        public System.Windows.Forms.Label rekordint;
        public System.Windows.Forms.Label login;
        private System.Windows.Forms.TextBox oldhaslowpisz;
        private System.Windows.Forms.Label podajaktualnehaslo;
        private System.Windows.Forms.TextBox newhaslowpisz;
        private System.Windows.Forms.TextBox newhaslopowtorz;
        private System.Windows.Forms.Label podajnowehaslo;
        private System.Windows.Forms.Label pwotorznowehaslo;
        private System.Windows.Forms.TextBox newloginwpisz;
        private System.Windows.Forms.Label podajnowylogin;
        private System.Windows.Forms.Button wstecz;
        private System.Windows.Forms.Button wprowadz;
        private System.Windows.Forms.Label komunikat;
        private System.Windows.Forms.Button usun;
    }
}